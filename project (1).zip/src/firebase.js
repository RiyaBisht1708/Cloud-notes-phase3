// In production, replace with real Firebase config

const mockDb = {
  semesters: [
    {
      id: 'sem1',
      name: 'Semester 1',
      subjects: [
        { id: 'cs101', title: 'Computer Fundamentals' },
        { id: 'math1', title: 'Calculus I' }
      ]
    },
    {
      id: 'sem2',
      name: 'Semester 2',
      subjects: [
        { id: 'oss', title: 'Operating Systems' },
        { id: 'dbms', title: 'Databases' }
      ]
    }
  ],
  materials: {}
};

// Mock Firebase exports
export const auth = {
  currentUser: null
};

export const storage = null;

export const db = {
  collection: (path) => ({
    getDocs: async () => {
      if (path === 'semesters') {
        return {
          docs: mockDb.semesters.map(sem => ({
            id: sem.id,
            data: () => ({ name: sem.name })
          }))
        };
      }
      return { docs: [] };
    }
  })
};

export default {};
