import React, { useState, useEffect, useRef } from 'react'

const DEMO_SEMESTERS = [
  {
    id: 'sem1',
    name: 'Semester 1',
    subjects: [
      { id: 'cs101', title: 'Computer Fundamentals' },
      { id: 'math1', title: 'Calculus I' }
    ]
  },
  {
    id: 'sem2',
    name: 'Semester 2',
    subjects: [
      { id: 'oss', title: 'Operating Systems' },
      { id: 'dbms', title: 'Databases' }
    ]
  }
]

const CATEGORIES = ['Theory', 'Practical', 'Assignments', 'PYQs', 'Projects']

function SemesterList({ semesters, selected, onSelect }) {
  const [expandedSem, setExpandedSem] = useState('sem1')
  const [search, setSearch] = useState('')
  const [newSemesterName, setNewSemesterName] = useState('')

  return (
    <div className="semesters-container">
      <h3 style={{ margin: 0, marginBottom: 16, fontSize: '20px' }}>📖 Semesters</h3>
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <form onSubmit={(e) => { e.preventDefault(); if (!newSemesterName.trim()) return; setNewSemesterName('') }} style={{ display: 'flex', gap: 8, width: '100%' }}>
          <input value={newSemesterName} onChange={e => setNewSemesterName(e.target.value)} placeholder="Add semester..." style={{ flex: 1 }} />
          <button type="submit">Add</button>
        </form>
      </div>
      <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search..." style={{ width: '100%', marginBottom: 16 }} />
      {semesters.map(sem => (
        <div key={sem.id} style={{ marginBottom: 12 }}>
          <button onClick={() => setExpandedSem(expandedSem === sem.id ? null : sem.id)} style={{ width: '100%', padding: 12, textAlign: 'left', background: '#f3f4f6', border: '1px solid #e5e7eb', borderRadius: 8, cursor: 'pointer', fontWeight: 700 }}>
            📚 {sem.name} {expandedSem === sem.id ? '▼' : '▶'}
          </button>
          {expandedSem === sem.id && (
            <div style={{ paddingLeft: 12, marginTop: 8 }}>
              {sem.subjects.map(sub => (
                <button key={sub.id} onClick={() => onSelect({ semesterId: sem.id, subjectId: sub.id })} style={{ display: 'block', width: '100%', textAlign: 'left', padding: 10, marginBottom: 6, background: selected.semesterId === sem.id && selected.subjectId === sub.id ? '#667eea' : '#fff', color: selected.semesterId === sem.id && selected.subjectId === sub.id ? '#fff' : '#1f2937', border: '1px solid #e5e7eb', borderRadius: 6, cursor: 'pointer' }}>
                  {sub.title}
                </button>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

function SubjectContent({ selected, categories, materials, setMaterials, cat, setCat }) {
  const [file, setFile] = useState(null)
  const [title, setTitle] = useState('')
  const [progress, setProgress] = useState(0)
  const [message, setMessage] = useState('')

  if (!selected.subjectId) {
    return (
      <div style={{ padding: 60, textAlign: 'center', background: 'rgba(102, 126, 234, 0.08)', borderRadius: 14 }}>
        <h2 style={{ color: '#667eea', marginBottom: 12 }}>Welcome</h2>
        <p>Select a subject to view materials</p>
      </div>
    )
  }

  const filteredMaterials = materials.filter(m => m.category === cat)

  return (
    <div>
      <h2 style={{ marginBottom: 8 }}>📂 {selected.subjectId}</h2>
      <p style={{ marginBottom: 20, color: '#6b7280' }}>Semester: {selected.semesterId}</p>
      <div style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap' }}>
        {categories.map(c => (
          <button key={c} onClick={() => setCat(c)} style={{ padding: '8px 14px', borderRadius: 20, border: 'none', background: cat === c ? '#667eea' : '#f3f4f6', color: cat === c ? '#fff' : '#1f2937', cursor: 'pointer', fontWeight: 600 }}>
            {c}
          </button>
        ))}
      </div>
      <div className="card" style={{ marginBottom: 28, padding: 28 }}>
        <h3>{cat} Materials ({filteredMaterials.length})</h3>
        {filteredMaterials.length === 0 && <p>No materials yet</p>}
        {filteredMaterials.map(m => (
          <div key={m.id} style={{ padding: 12, background: '#fff', border: '1px solid #e5e7eb', borderRadius: 8, marginBottom: 8, display: 'flex', justifyContent: 'space-between' }}>
            <div><div style={{ fontWeight: 700 }}>{m.title}</div><small style={{ color: '#6b7280' }}>{m.uploadedBy} • {new Date(m.uploadedAt).toLocaleDateString()}</small></div>
            <button onClick={() => setMaterials(materials.filter(x => x.id !== m.id))} style={{ padding: '6px 12px', borderRadius: 6, border: '1px solid #fecaca', background: '#fff', color: '#b91c1c', cursor: 'pointer' }}>Delete</button>
          </div>
        ))}
      </div>
      <form onSubmit={(e) => { e.preventDefault(); if (!file) return setMessage('Select a file'); setProgress(0); let p = 0; const int = setInterval(() => { p += Math.random() * 40; setProgress(Math.min(p, 99)) }, 100); setTimeout(() => { clearInterval(int); setProgress(100); setMaterials([...materials, { id: `m${Date.now()}`, title: title || file.name, category: cat, uploadedBy: 'demo-user', uploadedAt: new Date() }]); setMessage('✅ Uploaded!'); setFile(null); setTitle(''); setProgress(0); setTimeout(() => setMessage(''), 3000) }, 1500) }} className="card" style={{ padding: 24 }}>
        <h4>⬆️ Upload to {cat}</h4>
        <div style={{ display: 'grid', gap: 12 }}>
          <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Title (optional)" />
          <div style={{ padding: 16, border: '2px dashed #d1d5db', borderRadius: 10, textAlign: 'center', cursor: 'pointer' }}>
            <input type="file" onChange={e => { setFile(e.target.files[0]); setMessage('') }} style={{ display: 'none' }} id="file-input" />
            <label htmlFor="file-input" style={{ cursor: 'pointer', display: 'block' }}><div style={{ fontSize: 24, marginBottom: 8 }}>📁</div><span style={{ color: '#6b7280' }}>{file ? file.name : 'Click to upload'}</span></label>
          </div>
          <button type="submit">Upload File</button>
        </div>
        {progress > 0 && progress < 100 && (
          <div style={{ marginTop: 16 }}>
            <div style={{ fontSize: 12, marginBottom: 6 }}>Uploading: {Math.round(progress)}%</div>
            <div style={{ width: '100%', height: 6, background: '#e5e7eb', borderRadius: 10, overflow: 'hidden' }}><div style={{ width: `${progress}%`, height: '100%', background: '#667eea', transition: 'width 0.3s' }} /></div>
          </div>
        )}
        {message && <div style={{ marginTop: 12, padding: 12, borderRadius: 6, background: message.includes('✅') ? '#d1fae5' : '#fee2e2', color: message.includes('✅') ? '#065f46' : '#991b1b' }}>{message}</div>}
      </form>
    </div>
  )
}

export default function App() {
  const [selected, setSelected] = useState({ semesterId: 'sem1', subjectId: null })
  const [materials, setMaterials] = useState([{ id: 'mat1', title: 'Introduction to Programming', category: 'Theory', uploadedBy: 'demo-user', uploadedAt: new Date() }])
  const [cat, setCat] = useState(CATEGORIES[0])

  return (
    <div className="app">
      <div className="header">
        <div className="header-content">
          <div>
            <h1>📚 Academic Resource Hub</h1>
            <small>Your cloud-based academic materials repository</small>
          </div>
          <div className="header-actions">
            <span className="user-id">👤 Demo Mode</span>
          </div>
        </div>
      </div>
      <div className="main-container">
        <aside className={`sidebar visible`}>
          <SemesterList semesters={DEMO_SEMESTERS} selected={selected} onSelect={setSelected} />
        </aside>
        <main className="content">
          <SubjectContent selected={selected} categories={CATEGORIES} materials={materials} setMaterials={setMaterials} cat={cat} setCat={setCat} />
        </main>
      </div>
      <footer className="footer">
        <p>✅ Demo Mode Active | Study materials manager</p>
      </footer>
    </div>
  )
}
