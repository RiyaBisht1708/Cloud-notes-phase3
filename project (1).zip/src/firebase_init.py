# firebase_init.py
import os
import firebase_admin
from firebase_admin import credentials, storage
from google.cloud import storage as gcs_storage
from datetime import timedelta

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SERVICE_ACCOUNT = os.path.join(BASE_DIR, "firebase/serviceAccountKey.json")


BUCKET_NAME = "cloud-notes-firebase.firebasestorage.app"

cred = credentials.Certificate(SERVICE_ACCOUNT)
firebase_admin.initialize_app(cred, {
    'storageBucket': BUCKET_NAME
})

bucket = storage.bucket()
gcs_client = gcs_storage.Client.from_service_account_json(SERVICE_ACCOUNT)
gcs_bucket = gcs_client.bucket(BUCKET_NAME)
