# app.py
from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename
from firebase_init import bucket, gcs_bucket
from datetime import timedelta

app = Flask(__name__)

@app.route("/upload", methods=["POST"])
def upload_file():
    file = request.files.get("file")
    if not file:
        return jsonify({"error": "No file selected"}), 400

    filename = secure_filename(file.filename)
    blob_path = f"notes/{filename}"
    blob = bucket.blob(blob_path)

    # Upload file to Firebase
    blob.upload_from_file(file.stream, content_type=file.content_type)

    # Generate a signed download URL (valid for 7 days)
    gcs_blob = gcs_bucket.blob(blob_path)
    url = gcs_blob.generate_signed_url(
        expiration=timedelta(days=7),
        method="GET"
    )

    return jsonify({"message": "Uploaded successfully", "url": url}), 200
